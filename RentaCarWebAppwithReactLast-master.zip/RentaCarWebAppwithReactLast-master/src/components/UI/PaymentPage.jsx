import React from 'react'

export const PaymentPage = () => {
  return (
    <div className='center'>PaymentPage</div>
  )
}
